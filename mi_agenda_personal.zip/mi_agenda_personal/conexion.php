<?php

$servidor = "localhost";
$usuario = "root";
$password = "";
$basedatos = "mi_agenda_personal";

$conexion = new mysqli($servidor, $usuario, $password, $basedatos);

if ($conexion->connect_error) {
    die("Error de conexión");
}

?>