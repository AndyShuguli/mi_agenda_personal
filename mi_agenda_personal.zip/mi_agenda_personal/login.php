<?php
session_start();
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $correo = $_POST["correo"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM usuarios WHERE correo='$correo'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {

        $usuario = $resultado->fetch_assoc();

        if (password_verify($password, $usuario["password"])) {

            $_SESSION["id_usuario"] = $usuario["id"];
            $_SESSION["nombre"] = $usuario["nombre"];

            header("Location: dashboard.php");
            exit();

        } else {

            echo "Contraseña incorrecta";

        }

    } else {

        echo "Usuario no encontrado";

    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Iniciar Sesión</title>
</head>
<body>

<h2>Iniciar Sesión</h2>

<form method="POST">

    Correo:
    <input type="email" name="correo" required>
    <br><br>

    Contraseña:
    <input type="password" name="password" required>
    <br><br>

    <input type="submit" value="Ingresar">

</form>

<br><br>

<a href="registro.php">¿No tienes cuenta? Registrar nuevo usuario</a>

</body>
</html>