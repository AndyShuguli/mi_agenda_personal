<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $correo = $_POST["correo"];
    $ciudad = $_POST["ciudad"];

    $id_usuario = $_SESSION["id_usuario"];

    $sql = "INSERT INTO contactos_personales
    (id_usuario,nombre,telefono,correo,ciudad)
    VALUES
    ('$id_usuario','$nombre','$telefono','$correo','$ciudad')";

    if ($conexion->query($sql) === TRUE) {
        header("Location: dashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Nuevo Contacto</title>
</head>
<body>

<h2>Nuevo Contacto</h2>

<form method="POST">

Nombre:
<input type="text" name="nombre" required><br><br>

Teléfono:
<input type="text" name="telefono" required><br><br>

Correo:
<input type="email" name="correo" required><br><br>

Ciudad:
<input type="text" name="ciudad" required><br><br>

<input type="submit" value="Guardar">

</form>

</body>
</html>