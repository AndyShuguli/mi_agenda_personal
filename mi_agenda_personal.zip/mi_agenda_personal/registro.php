<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $password = $_POST["password"];

    $verificar = "SELECT * FROM usuarios WHERE correo='$correo'";
    $resultado = $conexion->query($verificar);

    if ($resultado->num_rows > 0) {

        echo "El correo ya existe";

    } else {

        $password_segura = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios(nombre, correo, password, fecha_registro)
                VALUES ('$nombre', '$correo', '$password_segura', CURDATE())";

        if ($conexion->query($sql) === TRUE) {

            header("Location: login.php");
            exit();

        } else {

            echo "Error al registrar";

        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro de Usuario</title>
</head>
<body>

<h2>Registro de Usuario</h2>

<form method="POST">

    Nombre:
    <input type="text" name="nombre" required>
    <br><br>

    Correo:
    <input type="email" name="correo" required>
    <br><br>

    Contraseña:
    <input type="password" name="password" required>
    <br><br>

    <input type="submit" value="Registrarse">

</form>

<br><br>

<a href="login.php">¿Ya tienes cuenta? Iniciar sesión</a>

</body>
</html>