<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

$id_usuario = $_SESSION["id_usuario"];

$sql = "SELECT * FROM contactos_personales WHERE id_usuario='$id_usuario'";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Panel Principal</title>
</head>
<body>

<h2>Bienvenido <?php echo $_SESSION["nombre"]; ?></h2>

<a href="crear_contacto.php">Nuevo contacto</a>

<br><br>

<a href="logout.php">Cerrar sesión</a>

<br><br>

<table border="1">

<tr>
    <th>Nombre</th>
    <th>Teléfono</th>
    <th>Correo</th>
    <th>Ciudad</th>
    <th>Acciones</th>
</tr>

<?php while($fila = $resultado->fetch_assoc()) { ?>

<tr>

<td><?php echo $fila["nombre"]; ?></td>
<td><?php echo $fila["telefono"]; ?></td>
<td><?php echo $fila["correo"]; ?></td>
<td><?php echo $fila["ciudad"]; ?></td>

<td>

<a href="editar_contacto.php?id=<?php echo $fila['id']; ?>">
Editar
</a>

<a href="eliminar_contacto.php?id=<?php echo $fila['id']; ?>"
onclick="return confirm('¿Está seguro de eliminar este contacto?');">
Eliminar
</a>

</td>

</tr>

<?php } ?>

</table>

</body>
</html>