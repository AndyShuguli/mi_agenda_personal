<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

$id = $_GET["id"];
$id_usuario = $_SESSION["id_usuario"];

$sql = "DELETE FROM contactos_personales
WHERE id='$id'
AND id_usuario='$id_usuario'";

$conexion->query($sql);

header("Location: dashboard.php");
exit();
?>