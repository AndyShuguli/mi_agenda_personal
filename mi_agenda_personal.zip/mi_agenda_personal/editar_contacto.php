<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit();
}

include("conexion.php");

$id = $_GET["id"];
$id_usuario = $_SESSION["id_usuario"];

$sql = "SELECT * FROM contactos_personales
WHERE id='$id'
AND id_usuario='$id_usuario'";

$resultado = $conexion->query($sql);
$contacto = $resultado->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST["nombre"];
    $telefono = $_POST["telefono"];
    $correo = $_POST["correo"];
    $ciudad = $_POST["ciudad"];

    $actualizar = "UPDATE contactos_personales SET
    nombre='$nombre',
    telefono='$telefono',
    correo='$correo',
    ciudad='$ciudad'
    WHERE id='$id'
    AND id_usuario='$id_usuario'";

    $conexion->query($actualizar);

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Contacto</title>
</head>
<body>

<h2>Editar Contacto</h2>

<form method="POST">

Nombre:
<input type="text" name="nombre" value="<?php echo $contacto['nombre']; ?>"><br><br>

Teléfono:
<input type="text" name="telefono" value="<?php echo $contacto['telefono']; ?>"><br><br>

Correo:
<input type="email" name="correo" value="<?php echo $contacto['correo']; ?>"><br><br>

Ciudad:
<input type="text" name="ciudad" value="<?php echo $contacto['ciudad']; ?>"><br><br>

<input type="submit" value="Actualizar">

</form>

</body>
</html>